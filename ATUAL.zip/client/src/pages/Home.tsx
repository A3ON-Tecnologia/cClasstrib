import { useState, useEffect } from "react";
import { X, AlertCircle, CheckCircle, ChevronDown, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface TabelaItem {
  ncm: string;
  cfop: string;
  cClasstrib_sugerido: string | null;
  qtd_registros: number;
  status: string;
  descricao: string;
  nome_produto: string;
}

interface CasoAusente {
  ncm: string;
  cfop: string;
  qtd_registros: number;
  descricao: string;
}

interface DadosJson {
  tabela_consolidada: TabelaItem[];
  casos_ausentes: CasoAusente[];
  resumo: {
    total_combinacoes: number;
    total_ok: number;
    total_ausente: number;
    total_multiplo: number;
  };
}

interface NCMAgrupado {
  ncm: string;
  descricao: string;
  cfops: TabelaItem[];
  expandido: boolean;
}

// Função para formatar cClasstrib com 6 dígitos
const formatarCClasstrib = (valor: string | null): string => {
  if (!valor) return "N/A";
  // Remover espaços e converter para string
  const limpo = String(valor).trim();
  // Se for "N/A" ou vazio, retornar N/A
  if (!limpo || limpo === "N/A") return "N/A";
  // Garantir 6 dígitos com zeros à esquerda
  return limpo.padStart(6, "0");
};

export default function Home() {
  const [dados, setDados] = useState<DadosJson | null>(null);
  const [modalAberto, setModalAberto] = useState(false);
  const [ncmsAgrupados, setNcmsAgrupados] = useState<NCMAgrupado[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [filtroStatus, setFiltroStatus] = useState<string>("todos");
  const [expandidosModal, setExpandidosModal] = useState<Set<string>>(new Set());

  useEffect(() => {
    const carregarDados = async () => {
      try {
        const resposta = await fetch("/dados.json");
        const json = await resposta.json();
        setDados(json);
        setCarregando(false);
      } catch (erro) {
        console.error("Erro ao carregar dados:", erro);
        setCarregando(false);
      }
    };

    carregarDados();
  }, []);

  const abrirModal = () => {
    if (dados) {
      const tabelaFiltrada = obterTabelaFiltrada();
      const agrupados = agruparPorNCM(tabelaFiltrada);
      setNcmsAgrupados(agrupados);
    }
    setModalAberto(true);
  };

  const fecharModal = () => {
    setModalAberto(false);
    setNcmsAgrupados([]);
    setExpandidosModal(new Set());
  };

  const agruparPorNCM = (tabela: TabelaItem[]): NCMAgrupado[] => {
    const mapa = new Map<string, TabelaItem[]>();
    const descricoes = new Map<string, string>();

    tabela.forEach((item) => {
      if (!mapa.has(item.ncm)) {
        mapa.set(item.ncm, []);
        descricoes.set(item.ncm, item.descricao);
      }
      mapa.get(item.ncm)!.push(item);
    });

    return Array.from(mapa.entries())
      .map(([ncm, cfops]) => ({
        ncm,
        descricao: descricoes.get(ncm) || "",
        cfops: cfops.sort((a, b) => parseInt(a.cfop) - parseInt(b.cfop)),
        expandido: false,
      }))
      .sort((a, b) => a.ncm.localeCompare(b.ncm));
  };

  const obterTabelaFiltrada = () => {
    if (!dados) return [];
    if (filtroStatus === "todos") return dados.tabela_consolidada;
    return dados.tabela_consolidada.filter((item) => item.status === filtroStatus);
  };

  const tabelaFiltrada = obterTabelaFiltrada();

  const toggleExpandir = (ncm: string) => {
    const novoExpandidos = new Set(expandidosModal);
    if (novoExpandidos.has(ncm)) {
      novoExpandidos.delete(ncm);
    } else {
      novoExpandidos.add(ncm);
    }
    setExpandidosModal(novoExpandidos);
  };

  const obterStatusGeral = (cfops: TabelaItem[]): string => {
    const temOk = cfops.some((c) => c.status === "OK");
    const temAusente = cfops.some((c) => c.status === "AUSENTE");

    if (temAusente && temOk) return "MISTO";
    if (temAusente) return "AUSENTE";
    return "OK";
  };

  const obterCorStatus = (status: string) => {
    switch (status) {
      case "OK":
        return "bg-green-100 text-green-800";
      case "AUSENTE":
        return "bg-amber-100 text-amber-800";
      case "MISTO":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-slate-100 text-slate-800";
    }
  };

  if (carregando) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando dados...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">
            Análise Tributária
          </h1>
          <p className="text-slate-600">
            Classificação de cClasstrib por NCM e CFOP
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Resumo Executivo */}
        {dados && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-blue-500">
              <div className="text-3xl font-bold text-blue-600 mb-2">
                {dados.resumo.total_combinacoes}
              </div>
              <p className="text-slate-600 text-sm">Combinações NCM × CFOP</p>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-green-500">
              <div className="text-3xl font-bold text-green-600 mb-2">
                {dados.resumo.total_ok}
              </div>
              <p className="text-slate-600 text-sm">Com cClasstrib Definido</p>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-amber-500">
              <div className="text-3xl font-bold text-amber-600 mb-2">
                {dados.resumo.total_ausente}
              </div>
              <p className="text-slate-600 text-sm">cClasstrib Ausente</p>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-slate-500">
              <div className="text-3xl font-bold text-slate-600 mb-2">
                {dados.resumo.total_multiplo}
              </div>
              <p className="text-slate-600 text-sm">Múltiplos Valores</p>
            </div>
          </div>
        )}

        {/* Filtros */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Filtros</h2>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={filtroStatus === "todos" ? "default" : "outline"}
              onClick={() => setFiltroStatus("todos")}
              className="rounded-full"
            >
              Todos ({dados?.resumo.total_combinacoes})
            </Button>
            <Button
              variant={filtroStatus === "OK" ? "default" : "outline"}
              onClick={() => setFiltroStatus("OK")}
              className="rounded-full"
            >
              OK ({dados?.resumo.total_ok})
            </Button>
            <Button
              variant={filtroStatus === "AUSENTE" ? "default" : "outline"}
              onClick={() => setFiltroStatus("AUSENTE")}
              className="rounded-full"
            >
              Ausente ({dados?.resumo.total_ausente})
            </Button>
            <Button
              variant="default"
              onClick={abrirModal}
              className="rounded-full ml-auto"
            >
              Visualizar Modal
            </Button>
          </div>
        </div>

        {/* Tabela de Combinações */}
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">
                    NCM
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">
                    CFOP
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">
                    cClasstrib
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">
                    Qtd. Registros
                  </th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-slate-900">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {tabelaFiltrada.map((item, idx) => (
                  <tr
                    key={idx}
                    className="hover:bg-slate-50 transition-colors"
                  >
                    <td className="px-6 py-4 text-sm font-medium text-blue-600">
                      {item.ncm}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {item.cfop}
                    </td>
                    <td className="px-6 py-4 text-sm font-mono text-slate-900 font-bold">
                      {formatarCClasstrib(item.cClasstrib_sugerido)}
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-600">
                      {item.qtd_registros}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
                          item.status === "OK"
                            ? "bg-green-100 text-green-800"
                            : item.status === "AUSENTE"
                              ? "bg-amber-100 text-amber-800"
                              : "bg-slate-100 text-slate-800"
                        }`}
                      >
                        {item.status === "OK" && (
                          <CheckCircle size={14} />
                        )}
                        {item.status === "AUSENTE" && (
                          <AlertCircle size={14} />
                        )}
                        {item.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {tabelaFiltrada.length === 0 && (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <p className="text-slate-600">
              Nenhum resultado encontrado para o filtro selecionado.
            </p>
          </div>
        )}
      </main>

      {/* Modal Hierárquico */}
      {modalAberto && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 flex items-center justify-between text-white">
              <h2 className="text-2xl font-bold">
                Análise por NCM
              </h2>
              <button
                onClick={fecharModal}
                className="text-white hover:bg-blue-800 rounded-lg p-1 transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            {/* Modal Content */}
            <div className="overflow-y-auto flex-1 p-6">
              {ncmsAgrupados.length > 0 ? (
                <div className="space-y-3">
                  {ncmsAgrupados.map((ncmGrupo) => (
                    <div key={ncmGrupo.ncm} className="border border-slate-200 rounded-lg overflow-hidden">
                      {/* NCM Header - Clicável */}
                      <button
                        onClick={() => toggleExpandir(ncmGrupo.ncm)}
                        className="w-full bg-slate-50 hover:bg-slate-100 transition-colors px-6 py-4 flex items-center justify-between"
                      >
                        <div className="flex items-center gap-4 flex-1 text-left">
                          <div className="flex-shrink-0">
                            {expandidosModal.has(ncmGrupo.ncm) ? (
                              <ChevronDown size={20} className="text-blue-600" />
                            ) : (
                              <ChevronRight size={20} className="text-slate-400" />
                            )}
                          </div>
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-slate-900">
                              NCM: {ncmGrupo.ncm}
                            </h3>
                            {ncmGrupo.descricao && (
                              <p className="text-sm text-slate-600 mt-1">
                                {ncmGrupo.descricao}
                              </p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-3 flex-shrink-0">
                          <span className="text-sm font-medium text-slate-600 bg-slate-200 px-3 py-1 rounded-full">
                            {ncmGrupo.cfops.length} CFOP{ncmGrupo.cfops.length !== 1 ? "s" : ""}
                          </span>
                        </div>
                      </button>

                      {/* CFOP Details - Expandível */}
                      {expandidosModal.has(ncmGrupo.ncm) && (
                        <div className="bg-white border-t border-slate-200 divide-y divide-slate-200">
                          {ncmGrupo.cfops.map((cfop, idx) => (
                            <div
                              key={idx}
                              className="px-6 py-4 hover:bg-blue-50 transition-colors"
                            >
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-xs text-slate-500 uppercase tracking-wide font-semibold mb-1">
                                      CFOP
                                    </p>
                                    <p className="text-lg font-bold text-slate-900">
                                      {cfop.cfop}
                                    </p>
                                  </div>
                                  <div>
                                    <p className="text-xs text-slate-500 uppercase tracking-wide font-semibold mb-1">
                                      cClasstrib Sugerido
                                    </p>
                                    <p className="text-lg font-bold font-mono">
                                      {formatarCClasstrib(cfop.cClasstrib_sugerido) === "N/A" ? (
                                        <span className="text-amber-600">
                                          N/A
                                        </span>
                                      ) : (
                                        <span className="text-green-600">
                                          {formatarCClasstrib(cfop.cClasstrib_sugerido)}
                                        </span>
                                      )}
                                    </p>
                                  </div>
                                </div>
                                <div>
                                  <p className="text-xs text-slate-500 uppercase tracking-wide font-semibold mb-1">
                                    Nome do Produto
                                  </p>
                                  <p className="text-sm text-slate-700 leading-relaxed">
                                    {cfop.nome_produto || "Nao informado"}
                                  </p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-600 text-center py-8">
                  Nenhum dado disponível.
                </p>
              )}
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 border-t border-slate-200 px-6 py-4 flex justify-end gap-2">
              <Button variant="outline" onClick={fecharModal}>
                Fechar
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
